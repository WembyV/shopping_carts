---
name: convert_er_to_text
description: 將 ERD 轉為文字版資料庫模型敘述
---

# 目的
將使用者指定的 ER 轉成純文字的資料庫模型描述，必須包含 FK 與欄位說明。

# 輸出
- 將轉換後的資料庫模型描述存檔於 `docs/er.md`。**必須** 先檢查此檔案是否存在，如果存在，將原本的檔案名稱改為 `docs/er.md.bak`。
- 在第一行加上目前本地時間(使用終端機指令取得)
- 不要加上 ER 中沒有的資訊，例如建議事項
- 將 `docs/er.md` 內容完整同步更新 `.github/prompts/sql.prompt.md`