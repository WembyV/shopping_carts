---
name: dbms
description: 當使用者提問中出現跟資料庫有關的操作需求，例如`查詢王大明的住址與電話`、`修改王大明生日`、`刪除某個資料表`、‵修改某欄位的資料型態`...等，載入本文件
---

# 目的
- 文件讀取 **只能** 依據本文指示，**不可** 自行讀取其他檔案內容
- 根據 ER 產生 SQL Server 資料庫的 SQL 指令並透過 sqlcmd 應用程式執行

# ER 來源
開啟下列檔案 `@docs/er.md`

# 執行SQL指令方式
- DDL、DCL與DML這三項，先顯示預計執行的SQL指令，但**必須取得**使用者授權後才能執行
- DQL（查詢）與TCL（交易）這兩項，先顯示預計執行的SQL指令，**不需要**使用者授權可以直接使用 sqlcmd 執行
- 執行SQL指令必須開啟終端機後使用 sqlcmd 命令，但需要先檢查作業系統為 Windows 或 macOS

## 作業系統為 Windows 時，參數如下：
  ```
  sqlcmd -S localhost\SQLEXPRESS -E -d AddressBook -Q "SQL COMMAND"
  ```

## 作業系統為 macOS 時，參數如下：
  ```
  sqlcmd \
    -S localhost \
    -U sa \
    -P $SQLSERVER_PWD \
    -d AddressBook \
    -Q "SQL COMMAND"
  ```

# 資訊安全
- **不可以** 用任何方式或在任何位置顯示密碼資料

# Log
- 將該指令的說明與指令以附加的方式存檔至 `log/yyyy-mm-dd.md`
- 格式分成三個段落，如下。此外，在每一次附加新資料前加上 `---` 作為分隔
  1) # 🎈說明
  2) # SQL
      - 需美化 SQL 指令
  3) # 執行結果
      - 以 markdown 的表格語法呈現查詢結果

